package cat.xtec.ioc.dawm07eac2restaurant;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author German
 */
@MultipartConfig(location = "/tmp")
public class Carta extends HttpServlet {

    @EJB
    private ValidateArticleBeanLocal validation;
        
    private List<Article> articles = new ArrayList<Article>();
    
    //Directori on es guarden les imatges
    private static final String UPLOAD_DIR = "img";
    
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        Enumeration initValorations= getServletConfig().getInitParameterNames();
        while (initValorations.hasMoreElements()) {
            String name = (String) initValorations.nextElement();
            String values = getServletConfig().getInitParameter(name);
            Integer preu = Integer.parseInt(values);
            articles.add(new Article(name, preu));
            
        }
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        switch (action) {
            case "listArticles":
                listArticles(request, response);
                break;
            case "addArticleComanda":
                addArticleComanda(request, response);
                break;
            case "createArticle":
                createArticle(request, response);
                break;
        }
    }

    
    protected void listArticles(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        JSONObject json = new JSONObject();
        JSONArray array = new JSONArray();
        try (PrintWriter out = response.getWriter()) {
            for (Article article : articles) {
                response.setContentType("application/json");
                LinkedHashMap<String, String> jsonOrderedMap = new LinkedHashMap<String, String>();
                jsonOrderedMap.put("name", article.getName());
                jsonOrderedMap.put("preu", article.getPreu().toString());
                jsonOrderedMap.put("quantitat", Integer.toString(article.getQuantitat()));
                jsonOrderedMap.put("preuparcial", article.getPreuparcial().toString());
                /*
                P3 Si ja hi és al llistat de valorats
                 */
                if (checkArticleAfegitSession(request, article)) {
                    jsonOrderedMap.put("afegit", "SI");
                } else {
                    jsonOrderedMap.put("afegit", "NO");
                }

                /*
                END P3
                 */
                JSONObject member = new JSONObject(jsonOrderedMap);
                array.put(member);
            }
            json.put("jsonArray", array);
            out.print(json.toString());
            out.close();
        } catch (JSONException ex) {
            Logger.getLogger(Carta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    protected void addArticleComanda(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String articleAfegit= request.getParameter("article");
        Integer quantitat = Integer.parseInt(request.getParameter("quantitat"));
        try (PrintWriter out = response.getWriter()) {
            JSONObject json = new JSONObject();
            Double preu = -1.0;
            Double preuParcial = -1.0;
            for (Article unArticle : this.articles) {
                if (unArticle.getName().equals(articleAfegit)) {
                    preu = unArticle.getPreu();
                    
                    unArticle.setQuantitat(quantitat);
                    unArticle.setPreuparcial(quantitat * preu);
                    /*
                     P3
                     */
                    addArticleToSession(request, unArticle);
                    break;
                }
            }
            json.put("articleAfegit", articleAfegit);
            json.put("preuArticle", preu);
            json.put("quantitatArticle", quantitat);
            json.put("preuparcialArticle", preuParcial);
            out.print(json.toString());
            out.close();

        } catch (JSONException ex) {
            Logger.getLogger(Carta.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    

    protected void createArticle(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // gets absolute path of the web application
        String applicationPath = request.getServletContext().getRealPath("");
        // constructs path of the directory to save uploaded file
        String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;
        try {
            File fileSaveDir = new File(uploadFilePath);
            System.out.println("Upload File Directory=" + fileSaveDir.getAbsolutePath());
            Part p = request.getPart("fileImageName");
            if (isValidFileName(request.getParameter("fpname"), p.getSubmittedFileName())) {
                File file = new File(uploadFilePath, p.getSubmittedFileName());
                InputStream input = p.getInputStream();
                Files.copy(input, file.toPath(), REPLACE_EXISTING);
                Article newArticle = new Article(request.getParameter("fpname"), Integer.parseInt(request.getParameter("fprate")));
                this.articles.add(newArticle);
                response.sendRedirect("index.html");
            } else {
                System.out.println("getRequestDispatcher CONTEXT BEFORE");
                response.sendRedirect("index.html");
                response.setHeader("errorname", "Article no creat per nom incorrecte");
                System.out.println("getRequestDispatcher CONTEXT AFTER");
            }

        } catch (Exception e) {
            System.out.println("error message: " + e.getMessage());
        }

    }
    
    private boolean isValidFileName(String paramName, String fileName){
        boolean valid = false;
        valid = validation.isValidFileImageName(paramName, fileName);
        for (Article article: articles) {
            if (article.getName().equals(paramName)){
                valid = false;
            }
        }
        return valid;       
    }
    
    /*
     P3
     */
    private void addArticleToSession(HttpServletRequest request, Article article) {
        /*
         P3
         */
        try {
            ComandaLocal comandaBean = (ComandaLocal) request.getSession().getAttribute("comandabean");
            if (comandaBean == null) {
                comandaBean = (ComandaLocal) new InitialContext().lookup("java:global/dawm07eac2Restaurant/Comanda");
                comandaBean.setArticlesAfegits(new ArrayList<Article>());
                request.getSession().setAttribute("comandabean", comandaBean);
            }
            comandaBean.getArticlesAfegits().add(article);
        } catch (Exception ex) {
            System.out.println("error message: " + ex.getMessage());

        }
    }
    
    
    private Boolean checkArticleAfegitSession(HttpServletRequest request, Article article) {
        Boolean toReturn = false;
        try {
            
            ComandaLocal comandaBean = (ComandaLocal) request.getSession().getAttribute("comandabean");
            if (comandaBean == null) {
                comandaBean = (ComandaLocal) new InitialContext().lookup("java:global/dawm07eac2Restaurant/Comanda");
                comandaBean.setArticlesAfegits(new ArrayList<Article>());
                request.getSession().setAttribute("comandabean", comandaBean);
            }            
            for (Article p : comandaBean.getArticlesAfegits()) {
                if(p.getName().equals(article.getName())){
                    toReturn = true;
                    break;
                }                
            }           
        } catch (Exception ex) {
            System.out.println("error message: " + ex.getMessage());

        }
        return toReturn;
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
