package cat.xtec.ioc.dawm07eac2restaurant;

import javax.ejb.Local;

/**
 *
 * @author German
 */
@Local
public interface ValidateArticleBeanLocal {
    public Boolean isValidFileImageName(String articleName, String fileImageName);
}
