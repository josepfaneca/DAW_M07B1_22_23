package cat.xtec.ioc.dawm07eac2restaurant;

import java.util.regex.Pattern;
import javax.ejb.Stateless;

/**
 *
 * @author German
 */
@Stateless
public class ValidateArticleBean implements ValidateArticleBeanLocal {

    @Override
    public Boolean isValidFileImageName(String articleName, String fileImageName) {
        Boolean toReturn = false;
        String[] fileImageNameArray = fileImageName.split(Pattern.quote("."));
        if(fileImageNameArray[0].equals(articleName)){
            toReturn = true;
        }
        return toReturn;
    }

}
