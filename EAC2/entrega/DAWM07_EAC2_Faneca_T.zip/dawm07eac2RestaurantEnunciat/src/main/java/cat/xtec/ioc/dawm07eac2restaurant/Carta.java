package cat.xtec.ioc.dawm07eac2restaurant;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author German
 */
@MultipartConfig(location = "/tmp", fileSizeThreshold = 1024 * 1024, maxFileSize = 1024 * 1024 * 5, maxRequestSize = 1024 * 1024 * 5 * 5) //https://javaee.github.io/tutorial/servlets011.html
public class Carta extends HttpServlet {

    @EJB
    private ValidateArticleBeanLocal validation;

    private List<Article> articles = new ArrayList<Article>();

    //Directori on es guarden les imatges
    private static final String UPLOAD_DIR = "img";

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        Enumeration initArticle = getServletConfig().getInitParameterNames();
        while (initArticle.hasMoreElements()) {
            String nom = (String) initArticle.nextElement();
            String preu = getServletConfig().getInitParameter(nom);
            articles.add(new Article(nom, Integer.parseInt(preu)));
        }
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        switch (action) {
            case "listArticles":
                listArticles(request, response);
                break;
            case "addArticleComanda":
                addArticleComanda(request, response);
                break;
            case "createArticle":
                createArticle(request, response);
                break;
        }
    }

    /*TODO*
    A Carta.listArticles heu de llegir els articles de la llista (articles) i retornar-los en un
    JSON. Concretament, seguiu aquestes instruccions al peu de la lletra:
    o Definiu les variables
     JSONObject json = new JSONObject();
     JSONArray array = new JSONArray();
    o Per a cada article de la llista
     Definiu LinkedHashMap<String, String> jsonOrderedMap = new
    LinkedHashMap<String, String>();
     Fiqueu cada camp a jsonOrderedMap on la key és el nom del camp
     Fiqueu aquest HashMap dins d'un objecte json, exactament
     JSONObject member = new JSONObject(jsonOrderedMap);
     Afegiu aquest objecte a l'array JSON (member a array)
    o Al final afegiu l'array a l'objecte json inicial (la variable json) i imprimiu aquest
     json.put("jsonArray", array);
     out.print(json.toString());
     //on out és el PrinterWriter
     */
    protected void listArticles(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        JSONObject json = new JSONObject();
        JSONArray array = new JSONArray();

        try (PrintWriter out = response.getWriter()) {
            for (Article article : articles) {
                response.setContentType("application/json");
                LinkedHashMap<String, String> jsonOrderedMap = new LinkedHashMap<String, String>();
                jsonOrderedMap.put("name", article.getName()); //la mateixa clau que al JS
                jsonOrderedMap.put("preu", article.getPreu().toString());
                jsonOrderedMap.put("quantitat", Integer.toString(article.getQuantitat()));//falta este parametre
                //feu una crida a Feu una crida a checkJocPuntuatSession(request, joc) que
                //retornarà true o false
                //SI--> key=afegit valor=SI NO--> key=afegit valor=NO
                if (checkArticleAfegitSession(request, article)) {
                    jsonOrderedMap.put("afegit", "SI");
                } else {
                    jsonOrderedMap.put("afegit", "NO");
                }

                JSONObject member = new JSONObject(jsonOrderedMap);
                array.put(member);
            }
            json.put("jsonArray", array);
            out.print(json.toString());
            out.close();
        } catch (Exception ex) {
            System.out.println("ERROR message in listArticles methode: " + ex.getMessage());
        }
    }

    protected void addArticleComanda(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //Carta?action=addArticleComanda&article=" + article + "&quantitat=" + quantitat
        String article = request.getParameter("article");
        String quantitat = request.getParameter("quantitat");

        try (PrintWriter out = response.getWriter()) {
            JSONObject json = new JSONObject();
            for (Article articleAdd : this.articles) {
                if (articleAdd.getName().equals(article)) {
                    //setQuantitat i setPreuparcial
                    articleAdd.setQuantitat(Integer.parseInt(quantitat));
                    Double preuParcial = articleAdd.getPreu() * Integer.parseInt(quantitat);
                    articleAdd.setPreuparcial(preuParcial);
                    
                    //Fer una crida addArticleToSession(request, unArticle) Pregunta 3
                    addArticleToSession(request, articleAdd);

                    json.put("articleAfegit", articleAdd.getName());
                    json.put("preuArticle", articleAdd.getPreu().intValue());//numero enter 
                    json.put("quantitatArticle", articleAdd.getQuantitat());
                    json.put("preuparcialArticle", articleAdd.getPreuparcial());

                    break;
                }

            }
            out.print(json.toString());
            out.close();
        } catch (Exception ex) {
            System.out.println("ERROR message in addArticleComanda methode: " + ex.getMessage());
        }
    }

    protected void createArticle(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String applicationPath = request.getServletContext().getRealPath("");

        String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;

        try {
            File fileSaveDir = new File(uploadFilePath);
            Part p = request.getPart("fileImageName");
            String fpname = request.getParameter("fpname");
            String submitedFileName = p.getSubmittedFileName();
            boolean validacio = isValidFileName(fpname, submitedFileName);

            //validacio de la imatge, si esta ok afegir
            if (validacio) {
                File file = new File(uploadFilePath, p.getSubmittedFileName());
                InputStream input = p.getInputStream();
                Files.copy(input, file.toPath(), REPLACE_EXISTING);
                Article article = new Article(request.getParameter("fpname"), Integer.parseInt(request.getParameter("fprate")));
                this.articles.add(article);
                System.out.println("S'ha afegit l'article= " + fpname);
                response.sendRedirect("index.html");
            } else {
                response.sendRedirect("index.html");
                response.setHeader("errorname", "Nom d'article no valid");
            }

        } catch (Exception ex) {
            System.out.println("ERROR message in createArticle methode: " + ex.getMessage());

        }

    }

    private boolean isValidFileName(String paramName, String fileName) {

        boolean verifica = validation.isValidFileImageName(paramName, fileName);
        for (Article article : articles) {
            if (article.getName().equals(paramName)) {
                verifica = false;
            }
        }
        return verifica;
    }

    /*
     P3
     */
    private void addArticleToSession(HttpServletRequest request, Article article) {

        try {
            ComandaLocal comandaBean = (ComandaLocal) request.getSession().getAttribute("comandabean");
            if (comandaBean == null) {
                comandaBean = (ComandaLocal) new InitialContext().lookup("java:global/dawm07eac2RestaurantEnunciat/Comanda");
                comandaBean.setArticlesAfegits(new ArrayList<Article>());
                request.getSession().setAttribute("comandabean", comandaBean);
            }
            comandaBean.getArticlesAfegits().add(article);
        } catch (NamingException ex) {
            System.out.println("ERROR message in addArticleToSession methode: " + ex.getMessage());
        }

    }

    private Boolean checkArticleAfegitSession(HttpServletRequest request, Article article) {

        Boolean retorna = false;

        try {
            ComandaLocal comandaBean = (ComandaLocal) request.getSession().getAttribute("comandabean");

            if (comandaBean == null) {
                comandaBean = (ComandaLocal) new InitialContext().lookup("java:global/dawm07eac2RestaurantEnunciat/Comanda");
                comandaBean.setArticlesAfegits(new ArrayList<Article>());
                request.getSession().setAttribute("comandabean", comandaBean);
            }
            for (Article art : comandaBean.getArticlesAfegits()) {
                if (art.getName().equals(article.getName())) {
                    retorna = true;
                    break;
                }
            }

        } catch (NamingException ex) {
            System.out.println("ERROR message in checkArticleAfegitSession methode: " + ex.getMessage());
        }
        return retorna;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
