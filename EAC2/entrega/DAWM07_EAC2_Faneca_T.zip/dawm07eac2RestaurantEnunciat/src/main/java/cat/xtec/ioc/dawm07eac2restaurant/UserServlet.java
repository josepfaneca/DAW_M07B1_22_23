package cat.xtec.ioc.dawm07eac2restaurant;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author German
 */
@WebServlet(name = "UserServlet", urlPatterns = {"/user"})
public class UserServlet extends HttpServlet {

    @Resource
    Validator validator;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if (action != null) {
            switch (action) {
                case "formUser":
                    formUser(request, response);
                    break;
                case "newUser":
                    newUser(request, response);
                    break;
                default:
                    System.out.println("Action is not formUser or newUser");
                    break;
            }

        } else {
            System.out.println("Action is null");
        }

    }

    private void formUser(HttpServletRequest request, HttpServletResponse response) {
        try {
            UserLocal userBean = (UserLocal) request.getSession().getAttribute("userbean");
            if (userBean == null) {
                //crear l'objecte bean 
                userBean = (UserLocal) new InitialContext().lookup("java:global/dawm07eac2RestaurantEnunciat/User");
                //crear el paràmetre de sessió "userbean" amb aquest nou bean
                request.getSession().setAttribute("userbean", userBean);
            }
            //retornar un objecte JSONObject
            PrintWriter out = response.getWriter();
            response.setCharacterEncoding("utf-8");
            JSONObject json = new JSONObject();

            //els atributs de User, si null seran "" 
            if (userBean.getUser() == null) {
                json.put("user", "");
                json.put("name", "");
                json.put("lastname", "");
            } else {
                json.put("user", userBean.getUser());
                json.put("name", userBean.getName());
                json.put("lastname", userBean.getLastname());
            }
            out.print(json.toString());
            out.close();
        } catch (IOException | NamingException | JSONException ex) {
            Logger.getLogger(UserServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     *
     * @param request
     * @param response
     *
     * TODO Feu servir el bean UserLocal Recupereu l'objecte bean del paràmetre
     * de sessió "userbean" Actualitzeu les seves propietats amb els valors dels
     * paràmetres de la quest (user, name i lastname) Feu la validació del nom
     * Què s'ha de retornar? Si passa la validació, un objecte JSON simple amb
     * key "resposta" i lor "OK" Si no passa la validació, un objecte JSON
     * simple amb key "resposta" i valor el missatge de la validació
     *
     */
    private void newUser(HttpServletRequest request, HttpServletResponse response) {

        try {

            UserLocal userBean = (UserLocal) request.getSession().getAttribute("userbean");

            //Actualitzeu les seves propietats amb els valors dels paràmetres de la quest (user, name i lastname)
            userBean.setUser(request.getParameter("user"));
            userBean.setName(request.getParameter("name"));
            userBean.setLastname(request.getParameter("lastname"));

            //Feu la validació del nom
            String valida = "OK";
            for (ConstraintViolation constraintViolation : validator.validate(userBean)) {
                valida += " : " + constraintViolation.getMessage();
            }

            // Si no passa la validació, un objecte JSON simple amb key "resposta" i valor el missatge de la validació
            PrintWriter out = response.getWriter();
            response.setCharacterEncoding("utf-8");
            JSONObject json = new JSONObject();
            //key "resposta" i valor el missatge de la validació
            json.put("resposta", valida);
            out.print(json.toString());
            out.close();

        } catch (IOException | JSONException ex) {
            Logger.getLogger(UserServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
