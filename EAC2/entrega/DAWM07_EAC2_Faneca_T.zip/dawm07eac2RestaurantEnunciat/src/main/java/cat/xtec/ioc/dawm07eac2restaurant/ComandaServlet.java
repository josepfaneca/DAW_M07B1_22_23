package cat.xtec.ioc.dawm07eac2restaurant;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author German
 */
@WebServlet(name = "Comanda", urlPatterns = {"/comanda"})
public class ComandaServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //Implementeu la derivació segons el paràmetre action
        String action = request.getParameter("action");

        if (action != null) {

            switch (action) {
                case "articlesComandaList":
                    articlesList(request, response);
                    break;
                case "deleteArticle":
                    deleteArticle(request, response);
                    break;
                default:
                    break;
            }
        } else {
            System.out.println("paremeter acction is null");
        }

    }

    private void articlesList(HttpServletRequest request, HttpServletResponse response) {

        try {
            //agafeu el valor inicial d'un paràmetre de sessió "comandabean"
            ComandaLocal comandabean = (ComandaLocal) request.getSession().getAttribute("comandabean");

            //Si el valor és null, llavors heu de crear l'objecte comandabean i 
            //a mes crear el paràmetre de sessió "comandabean" amb aquest nou objecte
            if (comandabean == null) {
                comandabean = (ComandaLocal) new InitialContext().lookup("java:global/dawm07eac2RestaurantEnunciat/Comanda");
                comandabean.setArticlesAfegits(new ArrayList<Article>());
                request.getSession().setAttribute("comandabean", comandabean);
                
            }
            //
            response.setCharacterEncoding("utf-8");
            PrintWriter out = response.getWriter();
            JSONObject json = new JSONObject();
            JSONArray array = new JSONArray();
            response.setContentType("application/json");

            /*Retorneu el nom (key = name), el preu (key=preu), la quantitat
            (key=quantitat) i el preuParcial (key=preuparcial) de tots els articles (les keys
            del JSON són els noms dels camps)*/
            for (Article article : comandabean.getArticlesAfegits()) {
                LinkedHashMap<String, String> orderLinkedHashMap = new LinkedHashMap<String, String>();//ordre d'insercio
                orderLinkedHashMap.put("name", article.getName());
                orderLinkedHashMap.put("preu", Double.toString(article.getPreu()));
                orderLinkedHashMap.put("quantitat", Integer.toString(article.getQuantitat()));
                orderLinkedHashMap.put("preuparcial", Double.toString(article.getPreuparcial()));
                orderLinkedHashMap.put("afegit", "SI");//si no hi ha este paràmetre no calcula el js
                
                JSONObject jSONObject = new JSONObject(orderLinkedHashMap);
                array.put(jSONObject);
            }
            json.put("jsonArray", array);
            out.print(json.toString());
            out.close();
        } catch (NamingException | IOException | JSONException ex) {
            Logger.getLogger(ComandaServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void deleteArticle(HttpServletRequest request, HttpServletResponse response) {
        //comanda?action=deleteArticle&article=" + article
        try {
            ComandaLocal comandabean = (ComandaLocal) request.getSession().getAttribute("comandabean");
            String articleBorrar = request.getParameter("article");

            for (Article article : comandabean.getArticlesAfegits()) {
                if (article.getName().equals(articleBorrar)) {
                    //elimineu l'última quantitat i preu: setQuantitat() i setPreuparcial())
                    article.setQuantitat(0);
                    article.setPreuparcial(0.0);
                    //Elimineu l’article d'igual nom al passat per paràmetre
                    comandabean.getArticlesAfegits().remove(article);
                    break;
                }
            }
            //Un objecte JSON simple amb key "resposta" i valor "OK"
            String retornar = "OK";
            PrintWriter out = response.getWriter();
            response.setCharacterEncoding("utf-8");
            JSONObject json = new JSONObject();
            json.put("resposta", retornar);
            out.print(json.toString());
            out.close();
        } catch (IOException | JSONException ex) {
            Logger.getLogger(ComandaServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
