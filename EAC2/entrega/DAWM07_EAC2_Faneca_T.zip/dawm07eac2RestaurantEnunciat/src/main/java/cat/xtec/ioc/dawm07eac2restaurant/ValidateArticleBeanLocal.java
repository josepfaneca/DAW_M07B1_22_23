/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.dawm07eac2restaurant;

import javax.ejb.Local;

/**
 *
 * @author jfaneca
 */
@Local
public interface ValidateArticleBeanLocal {

    public Boolean isValidFileImageName(String articleName, String fileImageName);
}
