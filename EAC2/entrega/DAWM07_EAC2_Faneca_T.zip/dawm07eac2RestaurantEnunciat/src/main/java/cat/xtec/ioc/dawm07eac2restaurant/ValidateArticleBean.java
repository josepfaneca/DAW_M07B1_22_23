/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.dawm07eac2restaurant;

import java.util.regex.Pattern;
import javax.ejb.Stateless;

/**
 *
 * @author jfaneca
 */
@Stateless
public class ValidateArticleBean implements ValidateArticleBeanLocal {

    @Override
    public Boolean isValidFileImageName(String articleName, String fileImageName) {
        
        Boolean resultatValida = false;
        
        String[] arrayImatge = fileImageName.split(Pattern.quote(".")); //sense el Pattern no funciona
        String nomImatge = arrayImatge[0];
        
        if (nomImatge.equals(articleName)){
            resultatValida = true;
        }
        return resultatValida;
    }
    
    
}
